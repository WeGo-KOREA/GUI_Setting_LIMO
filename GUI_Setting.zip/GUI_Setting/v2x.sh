#!/bin/bash

echo ""
echo "=========================================================="
echo "=========================================================="
echo "same as roslaunch limo_bringup v2x.launch"
echo "=========================================================="
echo "=========================================================="

sleep 1

python /home/wego/wego_ws/src/limo_ros/limo_bringup/scripts/get_ip.py

sleep 1
roslaunch /home/wego/wego_ws/src/limo_ros/limo_bringup/launch/v2x.launch
