import xml.etree.ElementTree as ET
import socket

hostname = socket.gethostname()
ip_address = socket.gethostbyname(hostname)

ip_address = ip_address.replace('.', '_')
tree = ET.parse("/home/wego/wego_ws/src/limo_ros/limo_bringup/launch/v2x.launch")
root = tree.getroot()

for group in root.findall(".//group"):
    group.attrib['ns'] = ip_address

tree.write("/home/wego/wego_ws/src/limo_ros/limo_bringup/launch/v2x.launch")